from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

app = Client("vmess_bot")

def check_access(user_id):
    # Anda dapat menambahkan logika untuk memeriksa akses pengguna di sini
    return True

@app.on_callback_query(filters.regex(r'^create-vmess$'))
def create_vmess(_, callback_query):
    user_id = callback_query.from_user.id
    if not check_access(user_id):
        callback_query.answer("Access Denied")
        return

    message = callback_query.message
    message.reply_text("Please enter the Vmess user details.")

@app.on_message(filters.command("start"))
def start_command(_, message):
    user_id = message.from_user.id
    if not check_access(user_id):
        message.reply("Access Denied")
        return

    keyboard = InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("Create Vmess", callback_data="create-vmess"),
                InlineKeyboardButton("Delete Vmess", callback_data="delete-vmess"),
            ],
            [
                InlineKeyboardButton("Check Login Vmess", callback_data="login-vmess"),
            ],
        ]
    )

    message.reply("Vmess Menu:", reply_markup=keyboard)

if __name__ == "__main__":
    app.run()
